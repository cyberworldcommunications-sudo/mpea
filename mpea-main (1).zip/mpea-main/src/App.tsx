import React, { useState } from 'react';
import Header from './components/Header';
import BalanceCard from './components/BalanceCard';
import ActionButtons from './components/ActionButtons';
import SpendingCard from './components/SpendingCard';
import TransactionHistory from './components/TransactionHistory';
import BottomNavigation from './components/BottomNavigation';

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [showBalance, setShowBalance] = useState(true);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-md mx-auto bg-white min-h-screen relative">
        <Header />
        
        <BalanceCard 
          showBalance={showBalance} 
          onToggleBalance={() => setShowBalance(!showBalance)} 
        />
        
        <ActionButtons />
        
        <SpendingCard />
        
        <TransactionHistory />
        
        {/* Bottom padding to account for fixed navigation */}
        <div className="h-20"></div>
        
        <BottomNavigation 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
      </div>
    </div>
  );
}

export default App;