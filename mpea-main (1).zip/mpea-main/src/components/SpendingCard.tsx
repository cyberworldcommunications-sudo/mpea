import React from 'react';

export default function SpendingCard() {
  return (
    <div className="mx-4 mb-4">
      <div className="bg-gradient-to-br from-blue-500 via-purple-500 to-red-500 rounded-2xl p-6 text-white relative overflow-hidden">
        <div className="absolute top-4 right-4 w-16 h-16 border-2 border-white border-opacity-30 rounded-full flex items-center justify-center">
          <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full"></div>
        </div>
        
        <div className="space-y-4">
          <div>
            <p className="text-sm opacity-80 mb-1">TOTAL SPENT THIS MONTH</p>
            <p className="text-xl font-bold">KSH. 20,794.78</p>
          </div>
          
          <div>
            <p className="text-sm opacity-80 mb-1">DAILY AVERAGE</p>
            <p className="text-lg font-semibold">KSH. 1,599.60</p>
          </div>
        </div>
        
        <div className="flex justify-center mt-4 space-x-2">
          <div className="w-2 h-2 bg-white rounded-full"></div>
          <div className="w-2 h-2 bg-white bg-opacity-50 rounded-full"></div>
          <div className="w-2 h-2 bg-white bg-opacity-50 rounded-full"></div>
          <div className="w-2 h-2 bg-white bg-opacity-50 rounded-full"></div>
          <div className="w-2 h-2 bg-white bg-opacity-50 rounded-full"></div>
        </div>
      </div>
    </div>
  );
}