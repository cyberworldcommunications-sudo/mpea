import React from 'react';
import { ChevronRight } from 'lucide-react';

const transactions = [
  {
    id: 'SM',
    name: 'STEPHEN MBUTHIA MACHARIA',
    code: '254705847089',
    amount: '- KSH 130.00',
    time: '13 Aug, 02:35 PM',
    color: 'bg-blue-100 text-blue-600'
  },
  {
    id: 'PN',
    name: 'PENTRA NETWORKS LTD MIRE...',
    code: '37780',
    amount: '- KSH 300.00',
    time: '13 Aug, 02:28 PM',
    color: 'bg-green-100 text-green-600'
  },
  {
    id: 'HB',
    name: 'HOME BEST MATT VIA COOP BA...',
    code: '219559',
    amount: '- KSH 130.00',
    time: '13 Aug, 02:15 PM',
    color: 'bg-red-100 text-red-600'
  },
  {
    id: 'HA',
    name: 'HELPLINE INTERNATIONAL L...',
    code: '',
    amount: '- KSH 1,500.00',
    time: '12 Aug, 11:42 AM',
    color: 'bg-purple-100 text-purple-600'
  },
  {
  id: 'XO',
    name: 'XECO DEVELOPERS VIA KCB BA...',
    code: '854695',
    amount: '- KSH 3,000.00',
    time: '13 Aug, 02:35 PM',
    color: 'bg-blue-100 text-blue-600'
  },
  {
    id: 'JU',
    name: 'JUNE WANJIKU...',
    code: '254712071385',
    amount: '- KSH 60000.00',
    time: '13 Aug, 02:28 PM',
    color: 'bg-green-100 text-green-600'
  },
  {
    id: 'HB',
    name: 'NOVA ENTERPRISES VIA COOP BA...',
    code: '219559',
    amount: '- KSH 8,000.00',
    time: '13 Aug, 02:15 PM',
    color: 'bg-red-100 text-red-600'
  },
  {
    id: 'HA',
    name: 'KINGDOM INTERNATIONAL L...',
    code: '',
    amount: '- KSH 8,500.00',
    time: '12 Aug, 11:42 AM',
    color: 'bg-purple-100 text-purple-600'
  }
];

export default function TransactionHistory() {
  return (
    <div className="bg-neutral-50">
      <div className="flex items-center justify-between p-4 border-b border-gray-100">
        <h3 className="text-sm font-medium text-gray-600">M-PESA STATEMENTS</h3>
        <button className="text-sm text-green-600 font-medium hover:text-green-700 transition-colors">
          SEE ALL
        </button>
      </div>
      
      <div className="divide-y divide-gray-50">
        {transactions.map((transaction, index) => (
          <div key={index} className="p-4 hover:bg-gray-50 transition-colors cursor-pointer">
            <div className="flex items-center space-x-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${transaction.color}`}>
                <span className="text-sm font-bold">{transaction.id}</span>
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {transaction.name}
                  </p>
                  <p className="text-sm font-medium text-gray-900">
                    {transaction.amount}
                  </p>
                </div>
                <div className="flex items-center justify-between mt-1">
                  <p className="text-xs text-gray-500">{transaction.code}</p>
                  <p className="text-xs text-gray-500">{transaction.time}</p>
                </div>
              </div>
              
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}