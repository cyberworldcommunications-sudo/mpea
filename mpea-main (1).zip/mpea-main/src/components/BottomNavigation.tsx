import React from 'react';
import { Home, ArrowUpDown, Compass, PieChart, TrendingUp } from 'lucide-react';

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const navItems = [
  { id: 'home', icon: Home, label: 'HOME' },
  { id: 'transact', icon: ArrowUpDown, label: 'TRANSACT' },
  { id: 'discover', icon: Compass, label: 'DISCOVER' },
  { id: 'spend', icon: PieChart, label: 'MY SPEND' },
  { id: 'grow', icon: TrendingUp, label: 'GROW' },
];

export default function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  return (
    <div className="bg-white border-t border-gray-200 px-2 py-2 fixed bottom-0 left-0 right-0 max-w-md mx-auto">
      <div className="flex justify-around">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`flex flex-col items-center space-y-1 p-2 rounded-lg transition-colors ${
              activeTab === item.id
                ? 'text-green-600'
                : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span className="text-xs font-medium">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}