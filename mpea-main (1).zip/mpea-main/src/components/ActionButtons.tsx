import React from 'react';
import { ArrowUpDown, CreditCard, ArrowDownToLine, Phone } from 'lucide-react';

const actions = [
  { icon: ArrowUpDown, label: 'Send and request', color: 'bg-green-500', hoverColor: 'hover:bg-green-600' },
  { icon: CreditCard, label: 'Pay', color: 'bg-blue-500', hoverColor: 'hover:bg-blue-600' },
  { icon: ArrowDownToLine, label: 'Withdraw', color: 'bg-red-500', hoverColor: 'hover:bg-red-600' },
  { icon: Phone, label: 'Airtime and data', color: 'bg-cyan-500', hoverColor: 'hover:bg-cyan-600' },
];

export default function ActionButtons() {
  return (
    <div className="grid grid-cols-4 gap-4 px-4 py-4 bg-white">
      {actions.map((action, index) => (
        <div key={index} className="flex flex-col items-center">
          <button
            className={`${action.color} ${action.hoverColor} text-white w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 active:scale-95 shadow-md hover:shadow-lg mb-2`}
          >
            <action.icon className="w-5 h-5" />
          </button>
          <span className="text-xs text-gray-700 text-center leading-tight">
            {action.label}
          </span>
        </div>
      ))}
    </div>
  );
}