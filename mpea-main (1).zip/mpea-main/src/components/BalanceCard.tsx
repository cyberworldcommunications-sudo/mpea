import React from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface BalanceCardProps {
  showBalance: boolean;
  onToggleBalance: () => void;
}

export default function BalanceCard({ showBalance, onToggleBalance }: BalanceCardProps) {
  return (
    <div className="px-4 py-6 bg-neutral-100 rounded-lg"> {/* Added rounded-lg for rounded corners */}
      <div className="text-center">
        <div className="flex items-center justify-center mb-2">
          <span className="text-sm font-medium text-gray-600 mr-2">Float Balance</span>
          <button 
            onClick={onToggleBalance}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            {showBalance ? <Eye className="w-4 h-4 text-gray-600" /> : <EyeOff className="w-4 h-4 text-gray-600" />}
          </button>
        </div>
        <div className="mb-2">
          <div className="text-3xl font-bold text-gray-900">
            Ksh. {showBalance ? '25,750.20' : '***,***.***'}
          </div>
        </div>
        <div className="text-sm text-blue-500">
          Available Uza Credo Loan: KSH 34,400
        </div>
      </div>
    </div>
  );
}
